package foxlo.tech.customisation;

import android.app.Activity;
import android.graphics.drawable.Drawable;

public class HomeClass {

    public Drawable db;

    public Drawable getJsonData() {
        return db;
    }

    public void setJsonData(Drawable jsonData) {
        this.db = jsonData;
    }
}
